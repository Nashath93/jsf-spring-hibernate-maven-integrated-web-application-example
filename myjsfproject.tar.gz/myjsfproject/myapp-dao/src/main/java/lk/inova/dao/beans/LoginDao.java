package lk.inova.dao.beans;

public interface LoginDao {

	public void
	
}
